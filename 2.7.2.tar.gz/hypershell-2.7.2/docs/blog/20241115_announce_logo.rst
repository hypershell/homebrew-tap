.. _20241115_announce_logo:

New Logo and Discord Server
===========================

`November 15, 2024`

We've added a new logo to the project ahead of the `SC24 <https://sc24.supercomputing.org>`_ conference!

We've also created a `Discord <https://discord.gg/wmv5gyUfkN>`_ server to post questions,
discuss your project, share with the community, keep in touch with announcements and upcoming events!

-----

|
