``hs`` ``config`` ``set`` ``[-h]``
    ``SECTION[...].VAR`` ``VALUE`` ``[--system | --user | --local]``
