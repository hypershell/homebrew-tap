Arguments
^^^^^^^^^

SECTION[...].VAR
    Path to variable.

Options
^^^^^^^

``--site``
    Output originating site name only.
