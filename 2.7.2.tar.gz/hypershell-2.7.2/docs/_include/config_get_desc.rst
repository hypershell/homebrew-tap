Get configuration option.

If source is not specified; e.g., ``--local``, the output is the merged configuration
from all sources. Use the ``config which`` command to see where a specific
option originates from.

Output is pretty-printed using the configured console theme (default: monokai).
Colorization is disabled for non-TTY invocations.
