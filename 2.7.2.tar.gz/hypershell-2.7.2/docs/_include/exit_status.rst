0
    Success

1
    Usage statement printed

2
    Bad argument

3
    Bad configuration

4
    Signal interrupt (keyboard interrupt)

5
    Generic runtime error (non-specific)

6
    Internal error (unexpected)
