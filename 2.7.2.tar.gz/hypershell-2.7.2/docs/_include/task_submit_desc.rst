Submit individual task to the database.

A database must be configured. The task will not run until scheduled
by the server process. The task UUID will be printed to standard out.

See ``task info`` command.
