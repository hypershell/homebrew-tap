``hs`` ``config`` ``which`` ``[-h]``
    ``SECTION[...].VAR`` ``[--site]``
