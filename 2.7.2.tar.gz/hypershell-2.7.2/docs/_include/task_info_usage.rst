``hs`` ``info`` ``[-h]``
    ``ID`` ``[--stdout | --stderr | -x FIELD]`` ``[-f FORMAT]``
