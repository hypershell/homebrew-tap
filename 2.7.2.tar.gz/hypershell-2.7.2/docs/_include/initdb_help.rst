Actions
^^^^^^^

``--vacuum``
    Vacuum an existing database.

``--backup`` *PATH*
    Vacuum into backup file (SQLite only).

``--rotate``
    Rotate completed tasks to new database (SQLite only).

``-t``, ``--truncate``
    Truncate database (task metadata will be lost).

Options
^^^^^^^

``-y``, ``--yes``
    Auto-confirm action (default will prompt).
