``hs`` ``config`` ``get`` ``[-h]``
    ``[-x]`` ``[-r]`` ``SECTION[...].VAR`` ``[--system | --user | --local | --default]``
