Get metadata and/or task outputs.

Query for the full metadata on task by ID.
Extract a specific field using ``-x``/``--extract``.

Alternatively, dump the captured standard output or errors
from the finished task (if captured). These files are written
on the client host and synced with SFTP if necessary.
