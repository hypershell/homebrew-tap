Submit individual task and wait for completion.

A database must be configured. The task will not run until scheduled
by the server process. The <stdout> and <stderr> are written locally
as if run locally, requires the client to have ``--capture`` enabled.

See ``info`` and ``wait`` commands.
