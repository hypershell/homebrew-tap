Show origin of configuration option.
