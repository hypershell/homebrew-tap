``hs`` ``config`` ``[-h]`` ``[--system | --local | --user]``

``hs`` ``config`` ``get`` ``[-h]`` ``SECTION[...].VAR`` ``[-x]`` ``[-r]`` ``[--system | --user | --local | --default]``

``hs`` ``config`` ``set`` ``[-h]`` ``SECTION[...].VAR`` ``VALUE`` ``[--system | --user | --local]``

``hs`` ``config`` ``edit`` ``[-h]`` ``[--system | --user | --local]``

``hs`` ``config`` ``which`` ``[-h]`` ``SECTION[...].VAR`` ``[--site]``