Arguments
^^^^^^^^^

SECTION[...].VAR
    Path to variable.

VALUE
    Value to be set.

Options
^^^^^^^

``--system``
    Apply to system configuration.

``--user``
    Apply to user configuration. (default)

``--local``
    Apply to local configuration.
