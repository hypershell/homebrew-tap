``hs`` ``update`` ``[-h]`` ``ID`` ``FIELD`` ``VALUE``

``hs`` ``update``
    ``[ARG [ARG ...]]``
    ``[--cancel | --revert | --delete | --remove-tag KEY [KEY...]]``
    ``[-w COND [COND ...]]`` ``[-t TAG [TAG...]]``
    ``[--order-by FIELD [--desc] --limit NUM]``
    ``[--failed | --succeeded | --completed | --remaining]``
    ``[--no-confirm]``
