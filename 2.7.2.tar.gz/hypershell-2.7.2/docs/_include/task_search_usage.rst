``hs`` ``list`` ``[-h]``
    ``[FIELD [FIELD ...]]`` ``[-w COND [COND ...]]`` ``[-t TAG [TAG...]]``
    ``[--order-by FIELD [--desc]]`` ``[--count | --limit NUM]``
    ``[-f FORMAT | --json | --csv]`` ``[-d CHAR]``
    ``[--failed | --succeeded | --completed | --remaining]``

``hs`` ``list`` ``--fields``

``hs`` ``list`` ``--tag-keys``

``hs`` ``list`` ``--tag-values`` ``KEY``