Set configuration option.
