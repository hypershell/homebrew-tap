``hs`` ``server`` ``[-h]`` ``[FILE | --forever | --restart]``
    ``[-b NUM]`` ``[-w SEC]`` ``[-r NUM [--eager]]``
    ``[-H ADDR]`` ``[-p PORT]`` ``[-k KEY]`` ``[--no-db | --initdb]`` ``[--print | -f PATH]``
    ``[--no-confirm]``
