Options
^^^^^^^

``--system``
    Edit system configuration.

``--user``
    Edit user configuration (default).

``--local``
    Edit local configuration.
