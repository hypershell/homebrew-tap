Edit configuration with default editor.

The EDITOR/VISUAL environment variable must be set.
