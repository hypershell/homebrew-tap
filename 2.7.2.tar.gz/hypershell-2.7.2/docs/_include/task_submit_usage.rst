``hs`` ``task`` ``submit`` ``[-h]`` ``[-t TAG [TAG...]]`` ``--`` ``ARGS...``
