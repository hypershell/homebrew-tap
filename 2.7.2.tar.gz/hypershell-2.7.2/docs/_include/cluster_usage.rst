``hs cluster [-h]`` ``[FILE | --restart | --forever]``
    ``[-N NUM]`` ``[-t CMD]`` ``[-b SIZE]`` ``[-w SEC]``
    ``[-p PORT]`` ``[-r NUM [--eager]]`` ``[-f PATH]`` ``[--capture | [-o PATH] [-e PATH]]``
    ``[--ssh [HOST... | --ssh-group NAME] [--env] | --mpi | --launcher=ARGS...]``
    ``[--no-db | --initdb]`` ``[--no-confirm]`` ``[-d SEC]`` ``[-T SEC]`` ``[-W SEC]`` ``[-S SEC]``
    ``[--autoscaling [MODE] [-P SEC] [-F VALUE] [-I NUM] [-X NUM] [-Y NUM]]``
