Search tasks in the database.

A database must be configured.
Specifying *FIELD* names defines what is included in the output
(by default all fields are included).

This command maps directly to underlying SQL queries.
