``hs`` ``client`` ``[-h]``
    ``[-N NUM]`` ``[-t TEMPLATE]`` ``[-b SIZE]`` ``[-w SEC]`` ``[-H ADDR]`` ``[-p PORT]``
    ``[-k KEY]`` ``[--capture | [-o PATH] [-e PATH]]`` ``[--no-confirm]``
    ``[-d SEC]`` ``[-T SEC]`` ``[-W SEC]`` ``[-S SEC]``
