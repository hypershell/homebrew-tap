Commands
^^^^^^^^

``get``
    Get configuration option.

``set``
    Set configuration option.

``edit``
    Edit configuration with default editor.

``which``
    Show origin of configuration option.

Options
^^^^^^^

``--system``
    Show system-level config path.

``--user``
    Show user-level config path.

``--local``
    Show local-level config path.
