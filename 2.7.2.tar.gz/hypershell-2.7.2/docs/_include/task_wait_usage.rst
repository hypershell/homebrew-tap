``hs`` ``wait`` ``[-h]``
    ``ID`` ``[-n SEC]`` ``[--info [-f FORMAT] | --status | --return]``
