``hs`` ``run`` ``[-h]`` ``[-n SEC]`` ``[-t TAG [TAG...]]`` ``--`` ``ARGS...``
