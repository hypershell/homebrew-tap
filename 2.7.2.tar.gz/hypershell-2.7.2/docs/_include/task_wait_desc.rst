Wait for task to complete.

Poll the database periodically for the completion status
of the task. Block until completed.

Optionally, print task metadata after completion.
