``hs`` ``config`` ``edit`` ``[-h]``
    ``[--system | --user | --local]``
