``hs`` ``submit`` ``[-h]`` ``[ARGS... | -f FILE]``
    ``[-b NUM]`` ``[-w SEC]`` ``[--template CMD]`` ``[-t TAG...]`` ``[--initdb]``
