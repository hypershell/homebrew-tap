.. _cli_initdb:

Initdb
======

Usage
-----

.. include:: ../_include/initdb_usage.rst

Description
-----------

.. include:: ../_include/initdb_desc.rst

|

.. include:: ../_include/initdb_help.rst
