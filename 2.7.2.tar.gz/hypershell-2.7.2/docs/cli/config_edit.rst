.. _cli_config_edit:

Config Edit
===========

Usage
-----

.. include:: ../_include/config_edit_usage.rst

Description
-----------

.. include:: ../_include/config_edit_desc.rst

|

.. include:: ../_include/config_edit_help.rst
