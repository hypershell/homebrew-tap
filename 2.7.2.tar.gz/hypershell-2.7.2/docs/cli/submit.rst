.. _cli_submit:

Submit
======

Usage
-----

.. include:: ../_include/submit_usage.rst

Description
-----------

.. include:: ../_include/submit_desc.rst

|

.. include:: ../_include/submit_help.rst
