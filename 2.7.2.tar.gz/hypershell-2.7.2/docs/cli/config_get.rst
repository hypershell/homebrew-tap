.. _cli_config_get:

Config Get
==========

Usage
-----

.. include:: ../_include/config_get_usage.rst

Description
-----------

.. include:: ../_include/config_get_desc.rst

|

.. include:: ../_include/config_get_help.rst
