.. _cli_task_search:

List
====

Usage
-----

.. include:: ../_include/task_search_usage.rst

Description
-----------

.. include:: ../_include/task_search_desc.rst

|

.. include:: ../_include/task_search_help.rst
