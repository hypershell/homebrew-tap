.. _cli_task_run:

Run
===

Usage
-----

.. include:: ../_include/task_run_usage.rst

Description
-----------

.. include:: ../_include/task_run_desc.rst

|

.. include:: ../_include/task_run_help.rst
