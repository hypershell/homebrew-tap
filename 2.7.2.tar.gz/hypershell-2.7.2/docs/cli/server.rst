.. _cli_server:

Server
======

Usage
-----

.. include:: ../_include/server_usage.rst

Description
-----------

.. include:: ../_include/server_desc.rst

|

.. include:: ../_include/server_help.rst
