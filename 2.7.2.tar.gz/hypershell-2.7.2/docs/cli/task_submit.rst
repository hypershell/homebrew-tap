.. _cli_task_submit:

Submit
======

Usage
-----

.. include:: ../_include/task_submit_usage.rst

Description
-----------

.. include:: ../_include/task_submit_desc.rst

|

.. include:: ../_include/task_submit_help.rst
