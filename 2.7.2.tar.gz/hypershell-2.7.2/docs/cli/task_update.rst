.. _cli_task_update:

Update
======

Usage
-----

.. include:: ../_include/task_update_usage.rst

Description
-----------

.. include:: ../_include/task_update_desc.rst

|

.. include:: ../_include/task_update_help.rst
