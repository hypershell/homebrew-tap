.. _cli_task_wait:

Wait
====

Usage
-----

.. include:: ../_include/task_wait_usage.rst

Description
-----------

.. include:: ../_include/task_wait_desc.rst

|

.. include:: ../_include/task_wait_help.rst
