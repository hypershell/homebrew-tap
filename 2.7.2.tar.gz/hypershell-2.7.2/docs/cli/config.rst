.. _cli_config:

Config
======

Usage
-----

.. include:: ../_include/config_usage.rst

Description
-----------

.. include:: ../_include/config_desc.rst

|

.. include:: ../_include/config_help.rst
