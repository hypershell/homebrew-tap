.. _cli_task_info:

Info
====

Usage
-----

.. include:: ../_include/task_info_usage.rst

Description
-----------

.. include:: ../_include/task_info_desc.rst

|

.. include:: ../_include/task_info_help.rst
