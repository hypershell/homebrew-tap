.. _cli_client:

Client
======

Usage
-----

.. include:: ../_include/client_usage.rst

Description
-----------

.. include:: ../_include/client_desc.rst

|

.. include:: ../_include/client_help.rst
