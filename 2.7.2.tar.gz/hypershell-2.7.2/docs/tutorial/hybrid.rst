.. _tutorial_hybrid:

Hybrid
======

`Under construction` ...
