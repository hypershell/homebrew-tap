.. _templates:

Templates
=========

|

.. include:: _include/templates.rst

|
